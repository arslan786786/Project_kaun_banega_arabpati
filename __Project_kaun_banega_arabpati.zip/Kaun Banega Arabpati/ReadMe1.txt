Title: Kaun Banega Arabpati  ? ( Who want to be a billionaire ? )
Description: 1. Credits
~~~~~~~~~~~
Written and developed by Jayant Kumar Gandhi.
For more question sets mail me at kbap@jayantgandhi.com
Or visit me at www.jayantgandhi.com
2. Installation
~~~~~~~~~~~~~~~~
Unzip the 7 files to any directory and run Kbap.exe
Data.dat
Data2.dat
Egavga.bgi
Kbap.exe
Pallette.col
ReadMe.txt (this file)
Softrock.fnt
Make sure that all the files are in the same directory.
3. Troubleshooting
~~~~~~~~~~~~~~~~~~~
Make sure that all the files are in the same directory.
Also make sure that the file "Data2.dat" is writable. Remove 'Read-Only' attribute if there. Problem will also occur if you have all the files on a 'write-protected' disc.
Please report any problem you experience to prob@jayantgandhi.com with "Problems using KBAP" in subject line.
Hope that you enjoy the game. If you do then please give me your feedback at feedback@jayantgandhi.com or visit www.jayantgandhi.com.

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
